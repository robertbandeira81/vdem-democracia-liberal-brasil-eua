# 00_setup.R -------------------------------------------------------------
# Pacotes necessários para a replicação.
# Execute este script antes dos demais, caso ainda não tenha os pacotes instalados.

if (!requireNamespace("pacman", quietly = TRUE)) {
  install.packages("pacman")
}

pacman::p_load(
  vdemdata,
  tidyverse,
  scales
)
