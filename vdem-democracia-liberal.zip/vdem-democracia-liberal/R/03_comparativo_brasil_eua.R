# 03_comparativo_brasil_eua.R --------------------------------------------
# Objetivo: reunir Brasil e Estados Unidos em uma base comparativa simples.
# Este script depende da execução prévia dos scripts 01 e 02, pois usa os
# arquivos CSV exportados na pasta data_output.

source("R/00_setup.R")

br_bar <- read_csv("data_output/brasil_media_vdem_por_governo.csv", show_col_types = FALSE) |>
  mutate(pais = "Brasil")

usa_bar <- read_csv("data_output/eua_media_vdem_por_governo.csv", show_col_types = FALSE) |>
  mutate(pais = "Estados Unidos")

comparativo <- bind_rows(br_bar, usa_bar) |>
  select(pais, governo, media, n_anos)

print(comparativo)

write_csv(comparativo, "data_output/comparativo_brasil_eua_vdem.csv")
