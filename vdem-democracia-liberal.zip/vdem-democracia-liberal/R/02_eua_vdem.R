# 02_eua_vdem.R ----------------------------------------------------------
# Objetivo: calcular e visualizar a média do índice de democracia liberal
# do V-Dem para os Estados Unidos, por governo, entre 1988 e 2025.

source("R/00_setup.R")

data(vdem)

# 1. Recorte da base ------------------------------------------------------
usa_dem <- vdem |>
  filter(country_text_id == "USA", year >= 1988, year <= 2025) |>
  select(year, v2x_libdem) |>
  mutate(
    governo = case_when(
      year == 1988 ~ "Reagan",
      year %in% 1989:1992 ~ "Bush Sr.",
      year %in% 1993:2000 ~ "Clinton",
      year %in% 2001:2008 ~ "Bush Jr.",
      year %in% 2009:2016 ~ "Obama",
      year %in% 2017:2020 ~ "Trump I",
      year %in% 2021:2024 ~ "Biden",
      year == 2025 ~ "Trump II",
      TRUE ~ NA_character_
    )
  ) |>
  drop_na(governo)

# 2. Média por governo ----------------------------------------------------
usa_bar <- usa_dem |>
  group_by(governo) |>
  summarise(
    media = mean(v2x_libdem, na.rm = TRUE),
    n_anos = n(),
    .groups = "drop"
  ) |>
  mutate(
    governo = factor(
      governo,
      levels = c(
        "Reagan",
        "Bush Sr.",
        "Clinton",
        "Bush Jr.",
        "Obama",
        "Trump I",
        "Biden",
        "Trump II"
      )
    )
  )

print(usa_bar)

media_geral_usa <- mean(usa_bar$media, na.rm = TRUE)

# 3. Gráfico --------------------------------------------------------------
grafico_usa <- usa_bar |>
  arrange(media) |>
  mutate(governo = factor(governo, levels = governo)) |>
  ggplot(aes(x = media, y = governo)) +
  geom_vline(
    xintercept = media_geral_usa,
    linetype = "dashed",
    linewidth = 0.6,
    color = "grey35"
  ) +
  geom_segment(
    aes(x = 0.55, xend = media, y = governo, yend = governo),
    linewidth = 0.6,
    color = "grey60"
  ) +
  geom_point(size = 4) +
  geom_text(
    aes(label = sprintf("%.2f", media)),
    nudge_x = 0.01,
    hjust = 0,
    fontface = "bold",
    size = 4.8
  ) +
  scale_x_continuous(
    limits = c(0.55, 0.92),
    breaks = c(0.55, 0.6, 0.7, 0.8, 0.9),
    expand = expansion(mult = c(0, 0.08))
  ) +
  labs(
    title = "EUA: democracia liberal por governo",
    subtitle = "Média do índice V-Dem, 1988-2025",
    x = "Média do índice",
    y = NULL,
    caption = "Fonte: V-Dem. Nota: a linha tracejada indica a média geral do período."
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 16),
    plot.subtitle = element_text(margin = margin(b = 10)),
    axis.title.x = element_text(face = "bold"),
    axis.text = element_text(color = "black"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.caption = element_text(hjust = 0, size = 10)
  )

print(grafico_usa)

# 4. Exportação das saídas ------------------------------------------------
write_csv(usa_bar, "data_output/eua_media_vdem_por_governo.csv")
ggsave(
  filename = "figures/eua_democracia_liberal_por_governo.png",
  plot = grafico_usa,
  width = 10,
  height = 6,
  dpi = 300
)
